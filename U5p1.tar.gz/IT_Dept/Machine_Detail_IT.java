package IT_Dept;
public class Machine_Detail_IT
{
	int No_of_PC; 
	String configuration;
	public void setdata()
	{
		No_of_PC = 50;
		configuration = "Intel i3";
	}
	public void Display()
	{
		System.out.println("the number of pc " + No_of_PC+ " and Config of PC is "+ configuration);
	} 
}

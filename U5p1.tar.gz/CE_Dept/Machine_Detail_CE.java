package CE_Dept;
public class Machine_Detail_CE
{
	int No_of_PC; 
	String configuration;
	public void setdata()
	{
		No_of_PC = 100;
		configuration = "Intel i9";
	}
	public void Display()
	{
		System.out.println("the number of pc " + No_of_PC+ " and Config of PC is "+ configuration);
	}
}

/*Write a simple java application that creates two threads: One
thread creates even numbers and
another thread creates odd numbers.
Use of Thread Class*/
import java.util.Random;
class NewODDThread extends Thread{
	Random r = new Random();
	int n;
	NewODDThread() {
		start(); // Start the thread
	}
	// This is the entry point for the second thread.
	public void run() {
		try {
			while(true)
		 	{
				n=r.nextInt(100);
				if ((n%2)==1)
				{
					System.out.println("Odd number " + n );
				}
				Thread.sleep(500);
			}
		} 
		catch (InterruptedException e) {
		System.out.println("Child interrupted.");
		}
		System.out.println("Exiting child thread.");
	}
}
class u7p1thread
{
	public static void main(String args[]) 
	{
		Random r = new Random();
		int n;
		new NewODDThread();
		Thread t1 = Thread.currentThread();
		System.out.println("Current thread: " + t1);
		// change the name of the thread	
		t1.setName("Main Thread");
		System.out.println("After name change: " + t1);
		try {
		 	while(true)
		 	{
				n=r.nextInt(100);
				if ((n%2)==0)
				{
					System.out.println("Even number " + n );
				}
				Thread.sleep(1000);
			}
		}
		catch (InterruptedException e) {
		System.out.println("Main thread interrupted");
		}
	}
	
}
